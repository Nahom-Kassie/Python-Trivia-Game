import random
import sys
import time
import json
import matplotlib.pyplot as plt
import threading # Import threading module
import queue # Import queue module for thread-safe communication

from requests.exceptions import RequestException
from pytrivia.trivia import Trivia
from pytrivia.enums import Category, Diffculty, Type

QUESTION_TIME_LIMIT = 15
RESULTS_FILE = 'trivia_results.json'

def load_results():
    try:
        with open(RESULTS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        print(f"⚠️ Warning: '{RESULTS_FILE}' is corrupted or empty. Starting with an empty results file.")
        return []

def save_results(results_data):
    try:
        with open(RESULTS_FILE, 'w') as f:
            json.dump(results_data, f, indent=4)
    except IOError as e:
        print(f"❌ Error: Could not save results to '{RESULTS_FILE}': {e}")

def analyze_results():
    all_trivia_results = load_results()

    if not all_trivia_results:
        print("\n📊 No results found to analyze. Play some trivia games first!")
        return

    category_data = {}
    difficulty_data = {}

    for result in all_trivia_results:
        cat = result.get('category', 'Unknown Category')
        diff = result.get('difficulty', 'Unknown Difficulty')
        correct = result.get('correctness', False)

        if cat not in category_data:
            category_data[cat] = {'total': 0, 'correct': 0}
        category_data[cat]['total'] += 1
        if correct:
            category_data[cat]['correct'] += 1

        if diff not in difficulty_data:
            difficulty_data[diff] = {'total': 0, 'correct': 0}
        difficulty_data[diff]['total'] += 1
        if correct:
            difficulty_data[diff]['correct'] += 1

    categories_names = []
    category_percentages = []
    category_total_questions = []

    for cat, data in sorted(category_data.items()):
        categories_names.append(cat)
        percentage = (data['correct'] / data['total'] * 100) if data['total'] > 0 else 0
        category_percentages.append(percentage)
        category_total_questions.append(data['total'])

    difficulty_levels = []
    difficulty_percentages = []
    difficulty_total_questions = []

    difficulty_order = ['Easy', 'Medium', 'Hard', 'Any', 'Unknown Difficulty']
    for diff in difficulty_order:
        if diff in difficulty_data:
            data = difficulty_data[diff]
            difficulty_levels.append(diff)
            percentage = (data['correct'] / data['total'] * 100) if data['total'] > 0 else 0
            difficulty_percentages.append(percentage)
            difficulty_total_questions.append(data['total'])

    plt.style.use('seaborn-v0_8-darkgrid')

    fig, axes = plt.subplots(2, 1, figsize=(12, 10))
    fig.suptitle('Trivia Performance Analysis', fontsize=16)

    if categories_names:
        axes[0].bar(categories_names, category_percentages, color='skyblue')
        axes[0].set_ylabel('Correctness Percentage (%)')
        axes[0].set_title('Performance by Category')
        axes[0].set_ylim(0, 100)
        axes[0].tick_params(axis='x', rotation=45)
        for i, perc in enumerate(category_percentages):
            axes[0].text(i, perc + 2, f'{perc:.1f}% ({category_total_questions[i]})', ha='center', va='bottom', fontsize=8)
    else:
        axes[0].text(0.5, 0.5, 'No Category Data Available', horizontalalignment='center', verticalalignment='center', transform=axes[0].transAxes, fontsize=12)
        axes[0].set_title('Performance by Category')

    if difficulty_levels:
        axes[1].bar(difficulty_levels, difficulty_percentages, color='lightcoral')
        axes[1].set_xlabel('Difficulty Level')
        axes[1].set_ylabel('Correctness Percentage (%)')
        axes[1].set_title('Performance by Difficulty')
        axes[1].set_ylim(0, 100)
        for i, perc in enumerate(difficulty_percentages):
            axes[1].text(i, perc + 2, f'{perc:.1f}% ({difficulty_total_questions[i]})', ha='center', va='bottom', fontsize=8)
    else:
        axes[1].text(0.5, 0.5, 'No Difficulty Data Available', horizontalalignment='center', verticalalignment='center', transform=axes[1].transAxes, fontsize=12)
        axes[1].set_title('Performance by Difficulty')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

# Function to read input in a separate thread
def get_input_threaded(q, prompt):
    try:
        user_input = input(prompt)
        q.put(user_input)
    except Exception as e:
        q.put(e) # Put the exception in the queue if one occurs

def play_trivia_game(num, my_category=None, my_difficulty=None):
    trivia = Trivia(with_token=True)

    all_trivia_results = load_results()

    try:
        data = trivia.request(num_questions=num, category=my_category, diffculty=my_difficulty)
    except RequestException:
        print("❌ Error: No internet connection. Please check your network and try again.")
        return

    if not data or 'results' not in data or not data['results']:
        print("🤷 No questions found for the selected category and/or difficulty or number of questions.")
        print("This might happen if the combination has few questions, or if the API had an issue.")
        print("Please try different options (e.g., a random category/difficulty).")
        return

    questions = data['results']
    score = 0

    category_display_name = my_category.name.replace('_', ' ').title() if my_category else "Random"
    difficulty_display_name = my_difficulty.name.title() if my_difficulty else "Any"

    for i, q in enumerate(questions, 1):
        question_text = q['question']
        correct_answer = q['correct_answer']
        incorrect_answers = q['incorrect_answers']

        all_answers = incorrect_answers + [correct_answer]
        random.shuffle(all_answers)

        print(f"\nQuestion {i}: {question_text}")
        for idx, ans in enumerate(all_answers):
            print(f"{idx + 1}. {ans}")

        user_answer_str = None
        input_queue = queue.Queue()
        # The prompt for the threaded input should ideally be handled within the thread
        # to avoid race conditions with the main thread's print statements.
        # However, for simplicity and to keep the original visual, we'll keep the
        # dynamic time left print in the main thread and let the input()
        # function handle its own prompt when the user starts typing.
        input_thread = threading.Thread(target=get_input_threaded, args=(input_queue, "")) # Empty prompt here
        input_thread.daemon = True # Allows the main program to exit even if the thread is still running
        input_thread.start()

        start_time = time.time()
        while True:
            time_elapsed = time.time() - start_time
            time_left = max(0, QUESTION_TIME_LIMIT - time_elapsed)

            # Check if input has been received from the thread
            try:
                # Use a small timeout for get() to avoid blocking if the queue is empty
                # This allows the loop to continue checking time_left
                user_answer_str = input_queue.get(timeout=0.01)
                if isinstance(user_answer_str, Exception): # Check if it's an exception
                    print(f"\nAn error occurred during input: {user_answer_str}")
                    user_answer_str = None # Treat as no input
                break # Exit the loop, input received
            except queue.Empty:
                # No input yet, continue checking time
                pass

            # Print the time left
            # Ensure the cursor returns to the start of the line and overwrites the previous time
            sys.stdout.write(f"\rYour answer (enter number) | Time left: {int(time_left)}s ")
            sys.stdout.flush()

            time.sleep(0.1) # Small delay to prevent busy-waiting

            if time_left <= 0:
                break # Time's up, exit the loop

        # Clear the timer line after input or timeout
        sys.stdout.write("\r" + " " * (len(f"Your answer (enter number) | Time left: {QUESTION_TIME_LIMIT}s ") + 5) + "\r")
        sys.stdout.flush()

        chosen_answer = None
        is_correct = False

        if user_answer_str is None:
            print("⏰ Time's up!")
            print(f"❌ Wrong! The correct answer was: {correct_answer}")
        else:
            try:
                user_choice = int(user_answer_str)

                if not (1 <= user_choice <= len(all_answers)):
                    print(f"⚠️ Invalid choice ({user_choice}). Please enter a number corresponding to an answer.")
                    print(f"❌ Wrong! The correct answer was: {correct_answer}")
                else:
                    chosen_answer = all_answers[user_choice - 1]
                    if chosen_answer == correct_answer:
                        print("✅ Correct!")
                        score += 1
                        is_correct = True
                    else:
                        print(f"❌ Wrong! The correct answer was: {correct_answer}")
            except ValueError:
                print(f"⚠️ Invalid input format. Please enter a number. The correct answer was: {correct_answer}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}. The correct answer was: {correct_answer}")

        question_result = {
            "question_number_in_game": i,
            "category": category_display_name,
            "difficulty": difficulty_display_name,
            "question_text": question_text,
            "correctness": is_correct,
            "chosen_answer": chosen_answer,
            "correct_answer": correct_answer,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        all_trivia_results.append(question_result)
        save_results(all_trivia_results)

    print(f"\n🏁 Done! You scored {score}/{num}\n")

if __name__ == "__main__":
    print("🎮 Welcome to the Python Trivia Game!\n")

    play_again = True
    while play_again:
        category_map = {member.name.replace('_', ' ').lower(): member for member in Category}

        print("Please choose a category from the list below (or press ENTER for a random category):")
        for cat_name in sorted(category_map.keys()):
            print(f"- {cat_name.title()}")
        print("---")

        selected_category_input = input("Your desired category: ").strip().lower()

        selected_category_enum = None
        if selected_category_input:
            if selected_category_input in category_map:
                selected_category_enum = category_map[selected_category_input]
            else:
                print(f"⚠️ '{selected_category_input.title()}' is not a valid category. Playing with a random category instead.")

        difficulty_map = {member.name.lower(): member for member in Diffculty}

        print("\nPlease choose a difficulty from the list below (or press ENTER for any difficulty):")
        for diff_name in sorted(difficulty_map.keys()):
            print(f"- {diff_name.title()}")
        print("---")

        selected_difficulty_input = input("Your desired difficulty: ").strip().lower()

        selected_difficulty_enum = None
        if selected_difficulty_input:
            if selected_difficulty_input in difficulty_map:
                selected_difficulty_enum = difficulty_map[selected_difficulty_input]
            else:
                print(f"⚠️ '{selected_difficulty_input.title()}' is not a valid difficulty. Choosing any difficulty instead.")

        while True:
            try:
                no_of_questions_str = input("Please input the number of questions you want (1-50): ")
                no_of_questions = int(no_of_questions_str)
                if 1 <= no_of_questions <= 50:
                    break
                else:
                    print("⚠️ Number of questions must be between 1 and 50.")
            except ValueError:
                print("⚠️ Invalid input. Please enter a whole number.")

        display_category_name = "a random"
        if selected_category_enum is not None:
            display_category_name = selected_category_enum.name.replace('_', ' ').title()

        display_difficulty_name = "any"
        if selected_difficulty_enum is not None:
            display_difficulty_name = selected_difficulty_enum.name.title()

        print(f"\nStarting trivia with {no_of_questions} questions from {display_category_name} category and {display_difficulty_name} difficulty...")

        play_trivia_game(no_of_questions, selected_category_enum, selected_difficulty_enum)

        while True:
            action_input = input("Do you want to play again (yes/no) or view results (view)? ").strip().lower()
            if action_input == 'yes':
                play_again = True
                print("\n--- Starting a new game! ---\n")
                break
            elif action_input == 'no':
                play_again = False
                print("Thanks for playing! Goodbye!")
                break
            elif action_input == 'view':
                analyze_results()
                print("\n--- Back to options ---")
            else:
                print("Invalid input. Please enter 'yes', 'no', or 'view'.")